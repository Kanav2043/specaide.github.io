SPECAIDE SITE BUNDLE (Yellow/Black + Apple-clean)

Upload the contents of this folder to your GitHub repository root.
- Replace existing: index.html, services.html, partners.html, about.html, contact.html, style.css
- Add folder: /brands (and the files inside)

Notes:
- Update contact details in contact.html (phone number).
- Update the NanoFilm and SMJ Carpets official URLs once confirmed (currently set to a Google search placeholder).
- Saint-Gobain has been removed (no page included).
